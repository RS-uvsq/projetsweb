<?php
require_once("Classes/connexion.class.php");
require_once("Classes/sh.class.php");
require_once("Classes/trace.php");
 
?>
<!DOCTYPE html >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" /> 
<link rel="stylesheet" href="her.css" type="text/css" />
<title>ACCUEIL</title>
</head>
<body>
<h1 style="color:red;text-decoration:underline;"> tous mes fichiers se trouvent dans le dossier <em style="color:blue">Classes </em> </h1>
<?php
//$monfichier= fopen("Classes/fac.txt", 'r');
$monfichier="J��<�<  N� 4748 R�capitulatif de votre d�marche en ligne ALLOCATIONS FAMILIALES Aujourd'hui le 21/01/2014 a 19:53:27, vous 

venez de faire une demande d'aide au logement. Vous allez devenir allocataire de la Caf des Yvelines situ�e : 1 Rue DE LA 

FONTAINE 78201 MANTES LA JOLIE CEDEX > Vous-m�me (allocataire et responsable du dossier) D�claration d'�tat civil de 

TSHOMOKONGO TARCISSE MR TSHOMOKONGO TARCISSE Nom d'usage : EDDY Ne(e) le: 15/08/1991 a KINSHASA CONGO Nationalit� : Autre 

Nom et pr�nom du p�re 
: EDIMAHAMBA 
TSHEFU Nom et 
pr�nom de la mere : MBU                         PAULINE Prestations TARCISSE TSHOMOKONGO ne per�oit pas ou n'a pas per�u de prestations familiales 

d'un autre organisme que la Caf Les parents                                            de TARCISSE TSHOMOKONGO ne per�oivent pas de prestations pour lui/elle. > Votre 

adresse 18 B Rue HARAS 78530 BUC France Date d'entr�e dans le logement : 01/11/2013 > Vos coordonn�es de contact M�l : 

tarcisseeddy@gmail.com Portable : 0752552824 > Votre compte bancaire Titulaire du compte : EDDY TARCISSE IBAN : FR76 3000 

4008 5900 0004 1551 863 BIC : BNPAFRPPXXX Domiciliation de l'agence bancaire :BNPPARBVERSAILLES ET GX > Votre situation 

familiale Vous avez d�clar� �tre c�libataire depuis le 15/08/1991. La loi punit quiconque se rend coupable de fraudes ou de 

fausses d�clarations (L.262-46 du Code de l'action sociale et des familles - Article 441.1 du code P�nal). La Caf v�rifie 

l'exactitude des d�clarations. La loi n° 78-17 du �janvier 1978 modifi�e, relative �  l'informatique et aux libert�s, 

s'applique aux r�ponses faites sur ce formulaire. Elle garantit un droit d'acc�s et de rectifications pour les donn�� vous 

concernant aupr�s de l'organisme qui a trait� votre demande. Emplacement r�serv� a la Caf PAGE 1/4 D�clarant MR TSHOMOKONGO 

TARCISSE 15/08/1991 21/01/2014 IDX T6093101 P";
 $f=myfu($monfichier);

//echo $f[0];
echo $er." ";

 /* foreach ($f as $op => $value)
   {
    
     
	echo "<pre> $op => $value </pre>";
	}*/
  
?>

<h2 style="color:green;">  OPERATION TERMINEE!!!" </h2>



</body>
</html>